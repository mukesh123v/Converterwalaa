
'use client';
import Link from 'next/link';
import { useState } from 'react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 w-full bg-white/90 backdrop-blur-md z-50 border-b border-gray-200">
      <div className="max-w-6xl mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          <Link href="/" className="flex items-center">
            <img 
              src="https://static.readdy.ai/image/c3edaf3b19493e59e7cced893009fb12/c80a2059c8cc4f2b6e3c2bbb51d064da.png"
              alt="Converterwala Logo"
              className="h-8 w-auto"
            />
          </Link>
          
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/" className="text-gray-700 hover:text-blue-600 transition-colors">Home</Link>
            <Link href="/generator" className="text-gray-700 hover:text-blue-600 transition-colors">Generator</Link>
            <Link href="/pricing" className="text-gray-700 hover:text-blue-600 transition-colors">Pricing</Link>
            <Link href="/about" className="text-gray-700 hover:text-blue-600 transition-colors">About</Link>
            <Link href="/contact" className="text-gray-700 hover:text-blue-600 transition-colors">Contact</Link>
            <Link href="/login" className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-2 !rounded-button hover:shadow-lg transition-all">Login</Link>
          </nav>

          <button 
            className="md:hidden p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <i className="ri-menu-line text-2xl"></i>
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4 space-y-3">
            <Link href="/" className="block text-gray-700 py-2">Home</Link>
            <Link href="/generator" className="block text-gray-700 py-2">Generator</Link>
            <Link href="/pricing" className="block text-gray-700 py-2">Pricing</Link>
            <Link href="/about" className="block text-gray-700 py-2">About</Link>
            <Link href="/contact" className="block text-gray-700 py-2">Contact</Link>
            <Link href="/login" className="block bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-2 !rounded-button text-center">Login</Link>
          </div>
        )}
      </div>
    </header>
  );
}
