
'use client';
import { useState } from 'react';
import Header from '../../components/Header';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (formData.message.length > 500) {
      alert('Message must be under 500 characters');
      return;
    }
    
    setIsSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      alert('Thank you for your message! We\'ll get back to you soon.');
      setFormData({ name: '', email: '', subject: '', message: '' });
      setIsSubmitting(false);
    }, 1000);
  };

  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="pt-28 pb-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Get In <span className="text-gradient">Touch</span> 📞
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Have questions, suggestions, or need help? We'd love to hear from you!
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl font-bold mb-8">Send us a message 💌</h2>
              
              <form onSubmit={handleSubmit} className="bg-white p-8 rounded-3xl card-shadow" id="contact-form">
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Name *
                    </label>
                    <input 
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      placeholder="Your full name"
                      className="w-full p-4 border-2 border-gray-200 !rounded-button focus:border-blue-500 focus:outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Email *
                    </label>
                    <input 
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      placeholder="your@email.com"
                      className="w-full p-4 border-2 border-gray-200 !rounded-button focus:border-blue-500 focus:outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Subject *
                    </label>
                    <select 
                      name="subject"
                      value={formData.subject}
                      onChange={(e) => setFormData({...formData, subject: e.target.value})}
                      className="w-full p-4 border-2 border-gray-200 !rounded-button focus:border-blue-500 focus:outline-none"
                      required
                    >
                      <option value="">Select a subject</option>
                      <option value="General Inquiry">General Inquiry</option>
                      <option value="Technical Support">Technical Support</option>
                      <option value="Billing Question">Billing Question</option>
                      <option value="Feature Request">Feature Request</option>
                      <option value="Partnership">Partnership</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Message * ({formData.message.length}/500)
                    </label>
                    <textarea 
                      name="message"
                      value={formData.message}
                      onChange={(e) => setFormData({...formData, message: e.target.value})}
                      placeholder="Tell us how we can help you..."
                      className="w-full p-4 border-2 border-gray-200 !rounded-button focus:border-blue-500 focus:outline-none h-32 resize-none"
                      maxLength={500}
                      required
                    ></textarea>
                  </div>

                  <button 
                    type="submit"
                    disabled={isSubmitting || formData.message.length > 500}
                    className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-4 px-6 !rounded-button hover:shadow-lg transition-all disabled:opacity-50 font-medium"
                  >
                    {isSubmitting ? '📤 Sending...' : '🚀 Send Message'}
                  </button>
                </div>
              </form>
            </div>

            <div>
              <h2 className="text-3xl font-bold mb-8">Other ways to reach us 🌐</h2>
              
              <div className="space-y-8">
                <div className="bg-white p-6 rounded-3xl card-shadow">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <i className="ri-mail-line text-blue-600 text-xl"></i>
                    </div>
                    <div>
                      <h3 className="font-bold text-lg mb-2">Email Support</h3>
                      <p className="text-gray-600 mb-2">Get help via email</p>
                      <a href="mailto:support@converterwala.com" className="text-blue-600 hover:underline">
                        support@converterwala.com
                      </a>
                    </div>
                  </div>
                </div>

                <div className="bg-white p-6 rounded-3xl card-shadow">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <i className="ri-whatsapp-line text-green-600 text-xl"></i>
                    </div>
                    <div>
                      <h3 className="font-bold text-lg mb-2">WhatsApp</h3>
                      <p className="text-gray-600 mb-2">Quick support on WhatsApp</p>
                      <a href="https://wa.me/919999999999" className="text-green-600 hover:underline">
                        +91 99999 99999
                      </a>
                    </div>
                  </div>
                </div>

                <div className="bg-white p-6 rounded-3xl card-shadow">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <i className="ri-instagram-line text-purple-600 text-xl"></i>
                    </div>
                    <div>
                      <h3 className="font-bold text-lg mb-2">Social Media</h3>
                      <p className="text-gray-600 mb-2">Follow us for updates</p>
                      <a href="https://instagram.com/converterwala" className="text-purple-600 hover:underline">
                        @converterwala
                      </a>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-6 rounded-3xl text-white">
                  <h3 className="font-bold text-lg mb-2">💬 Live Chat</h3>
                  <p className="mb-4 opacity-90">
                    Need instant help? Our live chat is available 24/7 for all your questions!
                  </p>
                  <button className="bg-white text-blue-600 px-6 py-2 !rounded-button hover:shadow-lg transition-all font-medium">
                    Start Live Chat
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-20 text-center">
            <h3 className="text-2xl font-bold mb-4">Response Time ⏰</h3>
            <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
              <div className="bg-white p-6 rounded-3xl card-shadow">
                <div className="text-2xl mb-2">📧</div>
                <h4 className="font-bold">Email</h4>
                <p className="text-gray-600 text-sm">Within 24 hours</p>
              </div>
              <div className="bg-white p-6 rounded-3xl card-shadow">
                <div className="text-2xl mb-2">💬</div>
                <h4 className="font-bold">Live Chat</h4>
                <p className="text-gray-600 text-sm">Instant response</p>
              </div>
              <div className="bg-white p-6 rounded-3xl card-shadow">
                <div className="text-2xl mb-2">📱</div>
                <h4 className="font-bold">WhatsApp</h4>
                <p className="text-gray-600 text-sm">Within 2 hours</p>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
