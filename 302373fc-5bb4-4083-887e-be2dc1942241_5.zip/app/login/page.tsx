
'use client';
import { useState } from 'react';
import Header from '../../components/Header';
import Link from 'next/link';

export default function Login() {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: ''
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle login/signup logic here
    console.log('Form submitted:', formData);
  };

  const handleGoogleLogin = () => {
    // Handle Google OAuth login
    console.log('Google login clicked');
  };

  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="pt-28 pb-20 px-4">
        <div className="max-w-md mx-auto">
          <div className="bg-white rounded-3xl p-8 card-shadow">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold mb-2">
                {isLogin ? 'Welcome Back! 👋' : 'Join Converterwala! 🎉'}
              </h1>
              <p className="text-gray-600">
                {isLogin ? 'Sign in to access your scripts' : 'Create your account to get started'}
              </p>
            </div>

            <button 
              onClick={handleGoogleLogin}
              className="w-full bg-white border-2 border-gray-200 text-gray-700 py-4 px-6 !rounded-button hover:border-blue-500 hover:text-blue-500 transition-all mb-6 flex items-center justify-center"
            >
              <i className="ri-google-fill text-xl mr-3 text-red-500"></i>
              Continue with Google
            </button>

            <div className="text-center text-gray-500 mb-6 relative">
              <span className="bg-white px-4 relative z-10">or</span>
              <div className="absolute top-1/2 left-0 right-0 h-px bg-gray-200"></div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              {!isLogin && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Full Name
                  </label>
                  <input 
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    placeholder="Enter your full name"
                    className="w-full p-4 border-2 border-gray-200 !rounded-button focus:border-blue-500 focus:outline-none"
                    required={!isLogin}
                  />
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email Address
                </label>
                <input 
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  placeholder="Enter your email"
                  className="w-full p-4 border-2 border-gray-200 !rounded-button focus:border-blue-500 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Password
                </label>
                <input 
                  type="password"
                  name="password"
                  value={formData.password}
                  onChange={(e) => setFormData({...formData, password: e.target.value})}
                  placeholder="Enter your password"
                  className="w-full p-4 border-2 border-gray-200 !rounded-button focus:border-blue-500 focus:outline-none"
                  required
                />
              </div>

              {isLogin && (
                <div className="text-right">
                  <button type="button" className="text-blue-500 hover:text-blue-600 text-sm">
                    Forgot Password?
                  </button>
                </div>
              )}

              <button 
                type="submit"
                className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-4 px-6 !rounded-button hover:shadow-lg transition-all font-medium"
              >
                {isLogin ? 'Sign In 🚀' : 'Create Account 🎉'}
              </button>
            </form>

            <div className="text-center mt-6">
              <p className="text-gray-600">
                {isLogin ? "Don't have an account? " : "Already have an account? "}
                <button 
                  onClick={() => setIsLogin(!isLogin)}
                  className="text-blue-500 hover:text-blue-600 font-medium"
                >
                  {isLogin ? 'Sign Up' : 'Sign In'}
                </button>
              </p>
            </div>

            {!isLogin && (
              <p className="text-xs text-gray-500 text-center mt-4">
                By signing up, you agree to our{' '}
                <Link href="/terms" className="text-blue-500 hover:underline">Terms of Service</Link>
                {' '}and{' '}
                <Link href="/privacy" className="text-blue-500 hover:underline">Privacy Policy</Link>
              </p>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
