
'use client';
import { useState } from 'react';
import Header from '../../components/Header';

export default function Generator() {
  const [formData, setFormData] = useState({
    niche: '',
    mood: '',
    language: '',
    topic: ''
  });
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedScript, setGeneratedScript] = useState(null);

  const niches = [
    'Lifestyle', 'Fashion', 'Food', 'Travel', 'Fitness', 'Technology', 
    'Beauty', 'Comedy', 'Education', 'Business', 'Motivation', 'Entertainment'
  ];

  const moods = [
    'Energetic', 'Calm', 'Funny', 'Inspiring', 'Educational', 'Trendy', 
    'Professional', 'Casual', 'Dramatic', 'Upbeat'
  ];

  const languages = ['English', 'Hindi', 'Hinglish'];

  const handleGenerate = async () => {
    if (!formData.niche || !formData.mood || !formData.language || !formData.topic) {
      alert('Please fill all fields');
      return;
    }

    setIsGenerating(true);
    
    // Simulate API call
    setTimeout(() => {
      setGeneratedScript({
        hook: `🔥 ${formData.topic} - You won't believe what happened next!`,
        scenes: [
          `Scene 1: Start with an attention-grabbing visual related to ${formData.topic}`,
          `Scene 2: Build suspense with ${formData.mood.toLowerCase()} energy`,
          `Scene 3: Reveal the main content with engaging storytelling`,
          `Scene 4: Add a twist or surprising element`,
          `Scene 5: End with a strong call-to-action`
        ],
        voiceover: `Hey everyone! Today I'm sharing something incredible about ${formData.topic}. This ${formData.mood.toLowerCase()} story will absolutely blow your mind. Make sure to watch till the end because the twist is amazing! Don't forget to like and follow for more content like this!`,
        hashtags: [
          '#reels', '#viral', '#trending', `#${formData.niche.toLowerCase()}`, 
          '#instagram', '#content', '#creator', '#converterwala'
        ]
      });
      setIsGenerating(false);
    }, 2000);
  };

  const handleCopy = () => {
    const script = `Hook: ${generatedScript.hook}\n\nScenes:\n${generatedScript.scenes.map((scene, i) => `${i + 1}. ${scene}`).join('\n')}\n\nVoiceover:\n${generatedScript.voiceover}\n\nHashtags:\n${generatedScript.hashtags.join(' ')}`;
    navigator.clipboard.writeText(script);
    alert('Script copied to clipboard!');
  };

  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="pt-28 pb-20 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              🎬 AI Reel Script Generator
            </h1>
            <p className="text-xl text-gray-600">
              Create viral Instagram reel scripts in seconds
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white p-8 rounded-3xl card-shadow">
              <h2 className="text-2xl font-bold mb-6 text-center">📝 Script Details</h2>
              
              <form className="space-y-6" id="script-generator">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Niche/Category 🎯
                  </label>
                  <select 
                    name="niche"
                    value={formData.niche}
                    onChange={(e) => setFormData({...formData, niche: e.target.value})}
                    className="w-full p-4 border-2 border-gray-200 !rounded-button focus:border-blue-500 focus:outline-none text-sm"
                  >
                    <option value="">Select your niche</option>
                    {niches.map(niche => (
                      <option key={niche} value={niche}>{niche}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Mood/Tone 🎭
                  </label>
                  <select 
                    name="mood"
                    value={formData.mood}
                    onChange={(e) => setFormData({...formData, mood: e.target.value})}
                    className="w-full p-4 border-2 border-gray-200 !rounded-button focus:border-blue-500 focus:outline-none text-sm"
                  >
                    <option value="">Select mood</option>
                    {moods.map(mood => (
                      <option key={mood} value={mood}>{mood}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Language 🌐
                  </label>
                  <select 
                    name="language"
                    value={formData.language}
                    onChange={(e) => setFormData({...formData, language: e.target.value})}
                    className="w-full p-4 border-2 border-gray-200 !rounded-button focus:border-blue-500 focus:outline-none text-sm"
                  >
                    <option value="">Select language</option>
                    {languages.map(language => (
                      <option key={language} value={language}>{language}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Topic/Theme 💡
                  </label>
                  <input 
                    type="text"
                    name="topic"
                    value={formData.topic}
                    onChange={(e) => setFormData({...formData, topic: e.target.value})}
                    placeholder="e.g., Morning routine, Recipe tips, Workout"
                    className="w-full p-4 border-2 border-gray-200 !rounded-button focus:border-blue-500 focus:outline-none text-sm"
                  />
                </div>

                <button 
                  type="button"
                  onClick={handleGenerate}
                  disabled={isGenerating}
                  className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-4 px-6 !rounded-button hover:shadow-lg transition-all disabled:opacity-50 text-lg font-medium"
                >
                  {isGenerating ? '🔄 Generating...' : '✨ Generate Script'}
                </button>
              </form>
            </div>

            <div className="bg-white p-8 rounded-3xl card-shadow">
              <h2 className="text-2xl font-bold mb-6 text-center">🎬 Generated Script</h2>
              
              {!generatedScript && !isGenerating && (
                <div className="text-center text-gray-500 py-20">
                  <i className="ri-file-text-line text-6xl mb-4 block"></i>
                  <p>Fill the form and click generate to create your script</p>
                </div>
              )}

              {isGenerating && (
                <div className="text-center py-20">
                  <div className="animate-spin w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
                  <p className="text-gray-600">Creating your viral script...</p>
                </div>
              )}

              {generatedScript && (
                <div className="space-y-6">
                  <div>
                    <h3 className="font-bold text-lg mb-2 text-blue-600">🎯 Hook:</h3>
                    <p className="bg-blue-50 p-3 rounded-xl">{generatedScript.hook}</p>
                  </div>

                  <div>
                    <h3 className="font-bold text-lg mb-2 text-green-600">🎬 Scenes:</h3>
                    <div className="space-y-2">
                      {generatedScript.scenes.map((scene, index) => (
                        <div key={index} className="bg-green-50 p-3 rounded-xl">
                          <strong>Scene {index + 1}:</strong> {scene.replace(`Scene ${index + 1}: `, '')}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="font-bold text-lg mb-2 text-purple-600">🎤 Voiceover:</h3>
                    <p className="bg-purple-50 p-3 rounded-xl">{generatedScript.voiceover}</p>
                  </div>

                  <div>
                    <h3 className="font-bold text-lg mb-2 text-orange-600">#️⃣ Hashtags:</h3>
                    <div className="bg-orange-50 p-3 rounded-xl">
                      {generatedScript.hashtags.map((tag, index) => (
                        <span key={index} className="inline-block bg-orange-200 px-2 py-1 rounded-full text-sm mr-2 mb-1">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>

                  <button 
                    onClick={handleCopy}
                    className="w-full bg-gradient-to-r from-green-500 to-teal-600 text-white py-3 px-6 !rounded-button hover:shadow-lg transition-all"
                  >
                    📋 Copy Script
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
