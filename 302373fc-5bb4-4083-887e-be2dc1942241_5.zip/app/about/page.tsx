
'use client';
import Header from '../../components/Header';
import Link from 'next/link';

export default function About() {
  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="pt-28 pb-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              About <span className="text-gradient">Converterwala</span> 🚀
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We're on a mission to democratize content creation by making viral Instagram reel scripts accessible to everyone through the power of AI.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-center mb-20">
            <div>
              <h2 className="text-3xl font-bold mb-6">Our Story 📖</h2>
              <p className="text-gray-600 text-lg mb-6">
                Founded in 2024, Converterwala was born from a simple observation: creating engaging Instagram reel content was taking creators hours of brainstorming and scripting. We knew there had to be a better way.
              </p>
              <p className="text-gray-600 text-lg mb-6">
                Our team of AI experts, content creators, and developers came together to build an intelligent solution that generates viral-worthy scripts in seconds, not hours.
              </p>
              <p className="text-gray-600 text-lg">
                Today, we're proud to serve thousands of creators, marketers, and businesses across India and beyond, helping them create content that truly converts.
              </p>
            </div>
            <div>
              <img 
                src="https://readdy.ai/api/search-image?query=modern%20office%20workspace%20with%20diverse%20team%20of%20young%20professionals%20working%20on%20laptops%2C%20creative%20startup%20environment%2C%20bright%20natural%20lighting%2C%20collaborative%20atmosphere%2C%20technology%20and%20innovation%2C%20contemporary%20office%20design%2C%20team%20working%20together%2C%20inspiring%20workspace%2C%20professional%20photography%20style&width=600&height=400&seq=team-workspace&orientation=landscape"
                alt="Our Team"
                className="w-full rounded-3xl card-shadow"
              />
            </div>
          </div>

          <div className="bg-white rounded-3xl p-12 card-shadow mb-20">
            <h2 className="text-3xl font-bold text-center mb-12">Our Values 💎</h2>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-20 h-20 mx-auto mb-6 flex items-center justify-center">
                  <img 
                    src="https://readdy.ai/api/search-image?query=icon%2C%203D%20cartoon%20innovation%20lightbulb%20with%20glowing%20effect%2C%20creative%20idea%20symbol%2C%20the%20icon%20should%20take%20up%2070%25%20of%20the%20frame%2C%20vibrant%20yellow%20and%20orange%20colors%20with%20soft%20gradients%2C%20minimalist%20design%2C%20smooth%20rounded%20shapes%2C%20subtle%20shading%2C%20no%20outlines%2C%20centered%20composition%2C%20isolated%20on%20white%20background%2C%20playful%20and%20friendly%20aesthetic%2C%20isometric%20perspective%2C%20high%20detail%20quality%2C%20clean%20and%20modern%20look%2C%20single%20object%20focus&width=100&height=100&seq=innovation-icon&orientation=squarish"
                    alt="Innovation"
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="text-xl font-bold mb-3">Innovation First</h3>
                <p className="text-gray-600">We continuously push the boundaries of AI technology to deliver cutting-edge solutions.</p>
              </div>
              
              <div className="text-center">
                <div className="w-20 h-20 mx-auto mb-6 flex items-center justify-center">
                  <img 
                    src="https://readdy.ai/api/search-image?query=icon%2C%203D%20cartoon%20community%20of%20people%20holding%20hands%20in%20circle%2C%20unity%20and%20collaboration%20symbol%2C%20the%20icon%20should%20take%20up%2070%25%20of%20the%20frame%2C%20vibrant%20blue%20and%20green%20colors%20with%20soft%20gradients%2C%20minimalist%20design%2C%20smooth%20rounded%20shapes%2C%20subtle%20shading%2C%20no%20outlines%2C%20centered%20composition%2C%20isolated%20on%20white%20background%2C%20playful%20and%20friendly%20aesthetic%2C%20isometric%20perspective%2C%20high%20detail%20quality%2C%20clean%20and%20modern%20look%2C%20single%20object%20focus&width=100&height=100&seq=community-icon&orientation=squarish"
                    alt="Community"
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="text-xl font-bold mb-3">Creator-Centric</h3>
                <p className="text-gray-600">Every feature we build is designed with our creators' success and convenience in mind.</p>
              </div>
              
              <div className="text-center">
                <div className="w-20 h-20 mx-auto mb-6 flex items-center justify-center">
                  <img 
                    src="https://readdy.ai/api/search-image?query=icon%2C%203D%20cartoon%20quality%20badge%20with%20star%20rating%2C%20excellence%20and%20premium%20symbol%2C%20the%20icon%20should%20take%20up%2070%25%20of%20the%20frame%2C%20vibrant%20gold%20and%20blue%20colors%20with%20soft%20gradients%2C%20minimalist%20design%2C%20smooth%20rounded%20shapes%2C%20subtle%20shading%2C%20no%20outlines%2C%20centered%20composition%2C%20isolated%20on%20white%20background%2C%20playful%20and%20friendly%20aesthetic%2C%20isometric%20perspective%2C%20high%20detail%20quality%2C%20clean%20and%20modern%20look%2C%20single%20object%20focus&width=100&height=100&seq=quality-icon&orientation=squarish"
                    alt="Quality"
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="text-xl font-bold mb-3">Quality Obsessed</h3>
                <p className="text-gray-600">We're committed to delivering the highest quality scripts that actually drive engagement and results.</p>
              </div>
            </div>
          </div>

          <div className="text-center">
            <h2 className="text-3xl font-bold mb-8">Ready to Join Our Community? 🌟</h2>
            <p className="text-xl text-gray-600 mb-8">
              Become part of thousands of creators who trust Converterwala for their content success.
            </p>
            <Link href="/generator" className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-12 py-4 text-xl !rounded-button hover:shadow-2xl transform hover:scale-105 transition-all inline-block">
              Start Creating Today 🚀
            </Link>
          </div>
        </div>
      </main>
    </div>
  );
}
