
'use client';
import Header from '../../components/Header';
import Link from 'next/link';

export default function Pricing() {
  const plans = [
    {
      name: 'Free Plan',
      price: '₹0',
      period: 'Forever',
      emoji: '🎯',
      features: [
        '3 scripts per day',
        'Basic script templates',
        'Hindi & English support',
        'Standard hashtags',
        'Community support'
      ],
      buttonText: 'Get Started Free',
      buttonStyle: 'border-2 border-gray-300 text-gray-700 hover:border-blue-500 hover:text-blue-500',
      popular: false
    },
    {
      name: 'Creator Plan',
      price: '₹199',
      period: '/month',
      emoji: '🚀',
      features: [
        'Unlimited scripts',
        'Premium templates',
        'Save & organize scripts',
        'Advanced hashtag research',
        'Priority support',
        'Export to multiple formats'
      ],
      buttonText: 'Upgrade to Creator',
      buttonStyle: 'bg-gradient-to-r from-blue-500 to-purple-600 text-white hover:shadow-xl',
      popular: true
    },
    {
      name: 'Pro Plan',
      price: '₹499',
      period: '/month',
      emoji: '👑',
      features: [
        'Everything in Creator',
        'Niche trend analysis',
        'PDF export with branding',
        'Analytics dashboard',
        'Custom script templates',
        '1-on-1 consultation call',
        'White-label rights'
      ],
      buttonText: 'Go Pro',
      buttonStyle: 'bg-gradient-to-r from-purple-500 to-pink-600 text-white hover:shadow-xl',
      popular: false
    }
  ];

  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="pt-28 pb-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Choose Your <span className="text-gradient">Perfect Plan</span> 💎
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Start free and upgrade as you grow. All plans include our core AI script generation features.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            {plans.map((plan, index) => (
              <div key={index} className={`bg-white rounded-3xl p-8 card-shadow relative hover:scale-105 transition-transform ${plan.popular ? 'ring-4 ring-blue-500 ring-opacity-50' : ''}`}>
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-2 rounded-full text-sm font-bold">
                      🔥 Most Popular
                    </span>
                  </div>
                )}
                
                <div className="text-center mb-8">
                  <div className="text-4xl mb-4">{plan.emoji}</div>
                  <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                  <div className="text-4xl font-bold text-gradient mb-1">{plan.price}</div>
                  <div className="text-gray-500">{plan.period}</div>
                </div>

                <ul className="space-y-4 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center">
                      <i className="ri-check-line text-green-500 text-xl mr-3"></i>
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>

                <button className={`w-full py-4 px-6 !rounded-button transition-all font-medium ${plan.buttonStyle}`}>
                  {plan.buttonText}
                </button>
              </div>
            ))}
          </div>

          <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-3xl p-8 md:p-12 text-white text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              🎉 Special Launch Offer!
            </h2>
            <p className="text-xl mb-6 opacity-90">
              Get 50% off on all paid plans for the first 3 months. Use code: <strong>LAUNCH50</strong>
            </p>
            <Link href="/generator" className="bg-white text-blue-600 px-8 py-4 !rounded-button hover:shadow-xl transition-all inline-block font-bold">
              Claim Your Discount Now! 🎁
            </Link>
          </div>

          <div className="mt-16 text-center">
            <h3 className="text-2xl font-bold mb-8">Frequently Asked Questions 🤔</h3>
            <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              <div className="bg-white p-6 rounded-3xl card-shadow">
                <h4 className="font-bold mb-3">Can I change plans anytime?</h4>
                <p className="text-gray-600">Yes! You can upgrade or downgrade your plan at any time. Changes take effect immediately.</p>
              </div>
              <div className="bg-white p-6 rounded-3xl card-shadow">
                <h4 className="font-bold mb-3">Is there a free trial?</h4>
                <p className="text-gray-600">Our free plan gives you 3 scripts daily forever. No credit card required to start!</p>
              </div>
              <div className="bg-white p-6 rounded-3xl card-shadow">
                <h4 className="font-bold mb-3">What payment methods do you accept?</h4>
                <p className="text-gray-600">We accept all major credit cards, debit cards, UPI, and net banking through Razorpay.</p>
              </div>
              <div className="bg-white p-6 rounded-3xl card-shadow">
                <h4 className="font-bold mb-3">Do you offer refunds?</h4>
                <p className="text-gray-600">Yes, we offer a 7-day money-back guarantee if you're not satisfied with our service.</p>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
