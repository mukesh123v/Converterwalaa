
'use client';
import Header from '../components/Header';
import Link from 'next/link';

export default function Home() {
  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="pt-20">
        <section className="py-20 px-4">
          <div className="max-w-6xl mx-auto text-center">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
              Generate Viral <span className="text-gradient">Instagram Reels</span> with AI 🤖
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 mb-12 max-w-3xl mx-auto">
              Create engaging reel scripts in seconds. Support for Hindi & English. Perfect for creators, marketers & businesses 🎬
            </p>
            
            <div className="flex flex-col md:flex-row gap-6 justify-center items-center mb-16">
              <Link href="/generator" className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-12 py-4 text-xl !rounded-button hover:shadow-2xl transform hover:scale-105 transition-all">
                🚀 Generate Script Now
              </Link>
              <Link href="/pricing" className="border-2 border-gray-300 text-gray-700 px-12 py-4 text-xl !rounded-button hover:border-blue-500 hover:text-blue-500 transition-all">
                View Pricing 💰
              </Link>
            </div>

            <div className="mb-20">
              <img 
                src="https://readdy.ai/api/search-image?query=modern%20smartphone%20displaying%20Instagram%20reels%20interface%20with%20colorful%20gradient%20background%2C%20sleek%20UI%20design%2C%20mobile%20app%20mockup%2C%20professional%20photography%20style%2C%20high%20quality%2C%20detailed%20screen%20content%2C%20soft%20lighting%2C%20minimal%20background&width=800&height=600&seq=hero-image&orientation=landscape"
                alt="Instagram Reels Generator"
                className="w-full max-w-4xl mx-auto rounded-3xl card-shadow"
              />
            </div>
          </div>
        </section>

        <section className="py-20 px-4 bg-white/50">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-4xl md:text-5xl font-bold text-center mb-16">
              Why Choose <span className="text-gradient">Converterwala</span>? ✨
            </h2>
            
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-white p-8 rounded-3xl card-shadow hover:scale-105 transition-transform text-center">
                <div className="w-20 h-20 mx-auto mb-6 flex items-center justify-center">
                  <img 
                    src="https://readdy.ai/api/search-image?query=icon%2C%203D%20cartoon%20AI%20robot%20brain%20with%20glowing%20neural%20networks%2C%20futuristic%20artificial%20intelligence%20symbol%2C%20the%20icon%20should%20take%20up%2070%25%20of%20the%20frame%2C%20vibrant%20blue%20and%20purple%20colors%20with%20soft%20gradients%2C%20minimalist%20design%2C%20smooth%20rounded%20shapes%2C%20subtle%20shading%2C%20no%20outlines%2C%20centered%20composition%2C%20isolated%20on%20white%20background%2C%20playful%20and%20friendly%20aesthetic%2C%20isometric%20perspective%2C%20high%20detail%20quality%2C%20clean%20and%20modern%20look%2C%20single%20object%20focus&width=100&height=100&seq=ai-icon&orientation=squarish"
                    alt="AI Powered"
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="text-2xl font-bold mb-4">AI-Powered Scripts</h3>
                <p className="text-gray-600">Advanced AI generates engaging, viral-ready scripts tailored to your niche and audience</p>
              </div>

              <div className="bg-white p-8 rounded-3xl card-shadow hover:scale-105 transition-transform text-center">
                <div className="w-20 h-20 mx-auto mb-6 flex items-center justify-center">
                  <img 
                    src="https://readdy.ai/api/search-image?query=icon%2C%203D%20cartoon%20language%20translation%20symbol%20with%20Hindi%20and%20English%20text%20bubbles%2C%20multilingual%20communication%20icon%2C%20the%20icon%20should%20take%20up%2070%25%20of%20the%20frame%2C%20vibrant%20colors%20with%20soft%20gradients%2C%20minimalist%20design%2C%20smooth%20rounded%20shapes%2C%20subtle%20shading%2C%20no%20outlines%2C%20centered%20composition%2C%20isolated%20on%20white%20background%2C%20playful%20and%20friendly%20aesthetic%2C%20isometric%20perspective%2C%20high%20detail%20quality%2C%20clean%20and%20modern%20look%2C%20single%20object%20focus&width=100&height=100&seq=language-icon&orientation=squarish"
                    alt="Multi Language"
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="text-2xl font-bold mb-4">Hindi & English Support</h3>
                <p className="text-gray-600">Generate scripts in both Hindi and English to reach your target audience effectively</p>
              </div>

              <div className="bg-white p-8 rounded-3xl card-shadow hover:scale-105 transition-transform text-center">
                <div className="w-20 h-20 mx-auto mb-6 flex items-center justify-center">
                  <img 
                    src="https://readdy.ai/api/search-image?query=icon%2C%203D%20cartoon%20lightning%20bolt%20with%20speed%20lines%2C%20instant%20results%20symbol%2C%20the%20icon%20should%20take%20up%2070%25%20of%20the%20frame%2C%20vibrant%20yellow%20and%20orange%20colors%20with%20soft%20gradients%2C%20minimalist%20design%2C%20smooth%20rounded%20shapes%2C%20subtle%20shading%2C%20no%20outlines%2C%20centered%20composition%2C%20isolated%20on%20white%20background%2C%20playful%20and%20friendly%20aesthetic%2C%20isometric%20perspective%2C%20high%20detail%20quality%2C%20clean%20and%20modern%20look%2C%20single%20object%20focus&width=100&height=100&seq=speed-icon&orientation=squarish"
                    alt="Instant Results"
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="text-2xl font-bold mb-4">Instant Results</h3>
                <p className="text-gray-600">Get professional-quality scripts in seconds, not hours. Save time and boost productivity</p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20 px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl md:text-5xl font-bold mb-8">
              Start Creating Viral Content Today! 🎯
            </h2>
            <p className="text-xl text-gray-600 mb-12">
              Join thousands of creators who trust Converterwala for their Instagram success
            </p>
            
            <Link href="/generator" className="bg-gradient-to-r from-purple-500 to-pink-600 text-white px-16 py-5 text-2xl !rounded-button hover:shadow-2xl transform hover:scale-105 transition-all inline-block">
              Get Started Free 🔥
            </Link>
            
            <div className="mt-8 text-sm text-gray-500">
              ✅ No credit card required • ✅ 3 free scripts daily • ✅ Instant access
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-gray-50 py-12 px-4 border-t border-gray-200">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-8">
            <Link href="/" className="text-3xl font-pacifico text-gradient mb-4 inline-block">
              Converterwala
            </Link>
            <p className="text-gray-600 max-w-2xl mx-auto">
              AI-powered Instagram Reel Script Generator helping creators and marketers create viral content effortlessly.
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-semibold text-gray-800 mb-3">Product</h4>
              <div className="space-y-2">
                <Link href="/generator" className="block text-gray-600 hover:text-blue-600 transition-colors">Script Generator</Link>
                <Link href="/pricing" className="block text-gray-600 hover:text-blue-600 transition-colors">Pricing</Link>
                <Link href="#" className="block text-gray-600 hover:text-blue-600 transition-colors">Features</Link>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-800 mb-3">Company</h4>
              <div className="space-y-2">
                <Link href="/about" className="block text-gray-600 hover:text-blue-600 transition-colors">About Us</Link>
                <Link href="/contact" className="block text-gray-600 hover:text-blue-600 transition-colors">Contact</Link>
                <Link href="#" className="block text-gray-600 hover:text-blue-600 transition-colors">Blog</Link>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-800 mb-3">Support</h4>
              <div className="space-y-2">
                <Link href="#" className="block text-gray-600 hover:text-blue-600 transition-colors">Help Center</Link>
                <Link href="#" className="block text-gray-600 hover:text-blue-600 transition-colors">Privacy Policy</Link>
                <Link href="#" className="block text-gray-600 hover:text-blue-600 transition-colors">Terms of Service</Link>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-800 mb-3">Connect</h4>
              <div className="space-y-2">
                <a href="#" className="block text-gray-600 hover:text-blue-600 transition-colors">Twitter</a>
                <a href="#" className="block text-gray-600 hover:text-blue-600 transition-colors">Instagram</a>
                <a href="#" className="block text-gray-600 hover:text-blue-600 transition-colors">LinkedIn</a>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-300 pt-8 text-center">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <p className="text-gray-600 text-sm mb-4 md:mb-0">
                © 2024 Converterwala. All rights reserved.
              </p>
              <div className="flex space-x-6 text-sm text-gray-600">
                <Link href="#" className="hover:text-blue-600 transition-colors">Privacy Policy</Link>
                <Link href="#" className="hover:text-blue-600 transition-colors">Terms of Service</Link>
                <Link href="#" className="hover:text-blue-600 transition-colors">Cookie Policy</Link>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
